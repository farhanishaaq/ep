<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateEmployeesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('employees', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('name');
			$table->string('password');
			$table->string('email');
			$table->string('gender');
			$table->integer('age');
			$table->string('city');
			$table->string('country');
			$table->string('address');
			$table->string('phone');
			$table->string('cnic');
			$table->string('branch');
			$table->text('note');
			$table->string('status');
			$table->string('role');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('employees');
	}

}
