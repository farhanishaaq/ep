<div class="row pB10">
    <div class="grid_12">
        <div class="header_1 wrap_3 color_3">
            Get in Touch
        </div>
        <div class="box_3">
            <ul class="list_1">
                <li><a class="fa fa-twitter" target="_blank" href="https://twitter.com/vu_emr"></a></li>
                <li><a class="fa fa-facebook" target="_blank" href="https://www.facebook.com/vuemr"></a></li>
                <li><a class="fa fa-google-plus" target="_blank" href="https://plus.google.com/104453698044276635098/about"></a></li>
                <li><a class="fa fa-pinterest" target="_blank" href="https://www.pinterest.com/vuemr/"></a></li>
            </ul>
        </div>
    </div>
</div>